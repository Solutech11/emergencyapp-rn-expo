import {
    StyleSheet,
    Text,
    View,
    ActivityIndicator,
    TouchableOpacity,
    TextInput,
    Keyboard,
    Button,
  } from "react-native";
  import React, { useEffect, useState } from "react";
 
  import AsyncStorage from "@react-native-async-storage/async-storage";
  
function Register(props) {
    const navi = props.nav;
    const [Username, setUsername] = useState('')
    const [Email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [location, setLocation] = useState('')
    const [state, setState] = useState('')
    const [desciption, setDesciption] = useState(``)
  
    const [Load, setLoad] = useState(false);
    const [ERRTXT, setERRTXT] = useState("");

    async function register() {
        if (Username.length>3 && Number.isNaN(Username)==true) {
            if (Email.length>=5) {
                var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
                if (Email.match(validRegex)) {
                    if (password.length>=6) {
                        var passw=  /^[A-Za-z]\w{7,14}$/;

                        if (password.match(passw)) {
                            if (location.length>=6 && Number.isNaN(location)==true) {
                                if (state.length>=2 && Number.isNaN(state)==true) {
                                    if (desciption.length>10 && Number.isNaN(desciption)) {
                                        const bdy = {
                                          username:Username,
                                          email:Email,
                                          password,
                                          location,state,description:desciption
                                        }

                                        await fetch('https://61dd-102-91-4-97.eu.ngrok.io/register',{
                                          method:'POST',
                                          headers:{
                                            Accept:'application/json',
                                            'Content-type':'application/json'
                                          },
                                          body:JSON.stringify(bdy)
                                        }).then(res=>res.json()).then(json=>{
                                          if (json.input==true) {
                                            AsyncStorage.setItem('id',json.user.main._id)
                                            AsyncStorage.setItem('username',json.user.main.Username)
                                            AsyncStorage.setItem('verf',json.user.main.verified )
                                            AsyncStorage.setItem('State',json.user.others.State)
                                            navi.pop()
                                          } else {
                                            setERRTXT('check input')
                                          }
                                        })
                                    } else {
                                        setERRTXT('Description should be greater than 10 characters nd should not be a number')
                                        
                                    }
                                } else {
                                setERRTXT('Error with state please contact admin')
                                    
                                }
                            } else {
                                setERRTXT('Location should be greater than 5 nd should not be a number')
                            }
                        } else {
                            setERRTXT('Invalid password')
                        }
                    } else {
                        setERRTXT('Password should be greater than 5')
                    }
                } else {
                    setERRTXT('Invalid email')
                }
            } else {
                setERRTXT('Email should be greater than 4')
            }
        } else {
            setERRTXT('username should be greater than 3 nd should not be a number')
        }
    }
    

    return (
      <View
        style={{
          display: props.disp,
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {Load ? (
          <ActivityIndicator size="large" color="black" />
        ) : (
          <View>
            <Text
              style={{
                textAlign: "center",
                marginBottom: 30,
                fontSize: 17,
                fontWeight: "400",
              }}
            >
              {ERRTXT}
            </Text>
  
            {/* username  */}
            <View style={styles.inpVIW}>
              <Text style={styles.label}>Username</Text>
              <TextInput
                onChangeText={setUsername}
                style={styles.inputs}
                placeholder="Username: JohnDoe123"
                keyboardType='default'
                autoComplete='username'
                autoFocus={true}
              />
            </View>
  
            {/* email */}
            <View style={styles.inpVIW}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                onChangeText={setEmail}
                style={styles.inputs}
                placeholder="Email: user@email.com"
                keyboardType="email-address"
                autoComplete="email"
                // autoFocus={true}
              />
            </View>
  
            {/* password */}
            <View style={styles.inpVIW}>
              <Text style={styles.label}>Password</Text>
              <TextInput
                onChangeText={setPassword}
                style={styles.inputs}
                placeholder="Password: a-z A-Z 0-9 example abc123$$"
                secureTextEntry
                autoComplete="password"
                maxLength={15}
              />
            </View>
  
            {/* location  */}
            <View style={styles.inpVIW}>
              <Text style={styles.label}>Location</Text>
              <TextInput
                onChangeText={setLocation}
                style={styles.inputs}
                placeholder="Location"
                keyboardType='default'
                autoComplete='postal-address-locality'
              />
            </View>
  
            {/* State  */}
            <View style={styles.inpVIW}>
              <Text style={styles.label}>State</Text>
              <TextInput
                onChangeText={setState}
                style={styles.inputs}
                placeholder="State"
                keyboardType='default'
                autoComplete='postal-address-locality'
              />
            </View>
  
            {/* Desciption  */}
            <View style={[styles.inpVIW,{height:50}]}>
              <Text style={styles.label}>State</Text>
              <TextInput
                onChangeText={setDesciption}
                style={styles.inputs}
                placeholder="Descriptions"
                keyboardType='default'
                multiline
              />
            </View>
  
            <Button title={props.title} color="black" />
          </View>
        )}
      </View>
    );
  }
  

export default Register

const styles = StyleSheet.create({
    body: {
      flex: 1,
    },
    header: {
      width: "100%",
      backgroundColor: "white",
      height: 40,
      justifyContent: "center",
      alignItems: "center",
      flexDirection: "row",
      // elevation:10,
      // shadowColor: '#000',
      //     shadowOffset: { width: 1, height: 1 },
      //     shadowOpacity:  0.4,
      //     shadowRadius: 3,
      // elevation: 5,
    },
    itemss: {
      width: "100%",
      backgroundColor: "white",
      marginVertical: 5,
      elevation: 3,
      padding: 10,
      borderRadius: 10,
    },
    inpVIW: {
      width: 300,
      // backgroundColor:'green',
      marginBottom: 30,
    },
    label: {
      fontSize: 15,
      fontWeight: "bold",
      marginBottom: 5,
    },
    inputs: {
      backgroundColor: "white",
      elevation: 5,
      borderRadius: 5,
      fontSize: 15,
      paddingHorizontal: 8,
    },
  });
  