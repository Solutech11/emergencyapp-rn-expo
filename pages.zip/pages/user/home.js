import { StyleSheet, Text, View,TouchableOpacity, Button } from 'react-native'
import React,{useState,useEffect} from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { Ionicons } from "@expo/vector-icons";

const UHome = ({navigation}) => {
  const [Data, setData] = useState({});
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState({})
  const [logged, setLogged] = useState(false)

  async function Getid() {
    try {
      const userid= await AsyncStorage.getItem('key')
      if (userid) {
        console.log(userid);
      } else {
        console.log('no');
      }
    } catch (error) {
      console.log(error);
    }
  }
  async function getApi() {
    setLoading(true);
    await fetch("https://61dd-102-91-4-97.eu.ngrok.io/", {
      method: "GET",
    })
      .then((res) => res.json())
      .then((json) => {
        // console.log(json);
        setData(json.lists);
        setLoading(false);
      })
      .catch((err) => {
        setLoading(true);
        Alert.alert("Internet connection");
      });
  }
  useEffect(() => {
    Getid()
    
  }, []);
  return (
    <SafeAreaView style={[styles.body, { backgroundColor: "white" }]}>
      {/* header  */}
      <View style={styles.header}>
        <Text style={{ fontWeight: "bold", fontSize: 20 }}>User Emergency</Text>
        {logged?<TouchableOpacity
          style={{ position: "absolute", right: 20 }}
          onPress={getApi}
        >
          <Ionicons name="reload" size={20} color="black" />
        </TouchableOpacity>:<View></View>}
        
      </View>

      {/* body  */}
      <View style={[styles.body, {backgroundColor:'#f2f2f2',flex:1, width:'100%',justifyContent:loading?'center':'flex-start' ,alignItems:'center'}]}>
        {logged?<Text>yes</Text>:<Button title='Login/ register' color='black' onPress={()=>navigation.navigate('auth')} />}
      </View>
    </SafeAreaView>
  )
}

export default UHome


const styles = StyleSheet.create({
  body:{
    flex:1
  },
  header:{
    width:'100%',
    backgroundColor:'white',
    height:40,
    justifyContent:'center',
    alignItems:'center',
    flexDirection:'row'
    // elevation:10,
    // shadowColor: '#000',
    //     shadowOffset: { width: 1, height: 1 },
    //     shadowOpacity:  0.4,
    //     shadowRadius: 3,
        // elevation: 5,
  },
  itemss:{
    width:'100%',
    backgroundColor:'white',
    marginVertical:5,
    elevation:3,
    padding:10,
    borderRadius:10
  }
})